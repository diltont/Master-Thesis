%% sript for checking the effect of training days on prediction(Scenario 2). The model is built on days combinations
% i.e. the whole data set was divided into two days combinations days 1 and
% 2, days 2 and 3 for buiding model and prediction was done for 1 hour on
% this build model.Likewise, the model is built on three days combinations
% i.e days 1,2 and 3, days 3,4,5 ....etc and prediction was done. The
% boxplot shows the RMSE values corresponding to predictions.



set(0, 'DefaultFigureVisible', 'on')
fit1=[];rm1=[];phall=[];dm1=[];mse1=[];
model=[];ph=[];dm=[];dmall=[];
k=1;
if timeGlucose(1)>500
    dm1=2:1:max(nextdayarray)-1;
else
    dm1=2:1:max(nextdayarray);
end
 
for i=1:length(dm1)
   j=1;dmk=[];
for dm=dm1(i):i:max(dm1)
%dm=2;

ph=(dm*96);
phall(dm-1)=ph;
cph=ph+1;
% if ph>192
%     ph=ph-96;
% end
res=mean(go(k:ph));
ymo=go(k:ph)'-res;
oiddt=iddata(ymo,[],900);
oycomp=go(cph:end);
yri=oycomp-mean(go(cph:end));
iddtr=iddata(yri',[],900);
% oodar=arorder1(iddtr);
model=ar(oiddt,odar,'ls','Ts',900);
oyp=predict(model,iddtr,6);
oyp=oyp.outputdata+(mean(go(cph:end)));
yfor=forecast(model,oiddt,4);
yfor=yfor.outputdata+res;
%  fc=sqrt(goodnessOfFit(oyp(1:4),oycomp(1:4)','MSE'));
 fc=sqrt(goodnessOfFit(yfor,oycomp(1:4)','MSE'));
rm=goodnessOfFit(yfor,oycomp(1:4)','MSE');
fit1.([ 'iter' num2str(i)]).(['modeldays' sprintf('%d',dm)])=fc;
rm1.([ 'iter' num2str(i)]).(['modeldays' sprintf('%d',dm)])=rm;
mse1.([ 'iter' num2str(i)]).(['modeldays' sprintf('%d',dm)])=model.Report.Fit.MSE;
aic1.([ 'iter' num2str(i)]).(['modeldays' sprintf('%d',dm)])=model.Report.Fit.AIC;
k=cph-96;
dmk(j)=dm;
j=j+1;
end
dmall{i}=dmk;
k=1;
end
 for i=1:length(dm1)
     fit11{i}=struct2cell(fit1.([ 'iter' num2str(i)]));
     fit11{i}=cell2mat(fit11{i}(1:end));
    mse11{i}=struct2cell(mse1.([ 'iter' num2str(i)]));
      mse11{i}=cell2mat(mse11{i}(1:end));
     aic11{i}=struct2cell(aic1.([ 'iter' num2str(i)]));
     aic11{i}=cell2mat(aic11{i}(1:end));
        
 end
figure()
% plot([2 2 2],[mean(cell2mat(struct2cell(fit1.iter1))) std(cell2mat(struct2cell(fit1.iter1))) -std(cell2mat(struct2cell(fit1.iter1)))  ],'*-');
plot(2:max(dm1) ,cellfun(@(x) mean(x),aic11),'*-');
set(gca, 'xtick',2:max(dm1));
xlabel('Days for training ')
ylabel('AIC')
title('Effect of training data on prediction-AR model')
figure()
% plot([2 2 2],[mean(cell2mat(struct2cell(fit1.iter1))) std(cell2mat(struct2cell(fit1.iter1))) -std(cell2mat(struct2cell(fit1.iter1)))  ],'*-');
plot(2:max(dm1) ,cellfun(@(x) mean(x),mse11),'*-');
set(gca, 'xtick',2:max(dm1));
xlabel('Days for training ')
ylabel('MSE')
title('Effect of training data on prediction-AR model')
figure()
% plot([2 2 2],[mean(cell2mat(struct2cell(fit1.iter1))) std(cell2mat(struct2cell(fit1.iter1))) -std(cell2mat(struct2cell(fit1.iter1)))  ],'*-');
plot(2:max(dm1) ,cellfun(@(x) (mean(x)),fit11),'*-');
set(gca, 'xtick',2:max(dm1));
xlabel('Days for training ')
ylabel('MSE')
title('Effect of training data on prediction-AR model(next 1 h)')
%%
fc=[];ymo=[];res=[];
for i=1:length(dm1)
   j=1;dmk=[];
for dm=dm1(i):i:max(dm1)
%dm=2;

ph=(dm*96);
phall(dm-1)=ph;
cph=ph+1;
% if ph>192
%     ph=ph-96;
% end
res=mean(go(k:ph));
ymo=go(k:ph)'-res;
oycomp=go(cph:end);
yri=oycomp-mean(go(cph:end));
rescarb=mean(firecarbdta(1:end-ph));resvet=mean(firevetdta(1:end-ph));
resstep=mean(firestep(1:end-ph));
arcarbmo=(firecarbdta(k:ph)'-rescarb);
arvetmo=(firevetdta(k:ph)'-resvet);
arstepmo=(firestep(k:ph)'-resstep);
mergedata=[arcarbmo arvetmo arstepmo];
mergedatav=[(firecarbdta(cph:end)'-rescarb) (firevetdta(cph:end)'-resvet) (firestep(cph:end)'-resstep)];
oiddt1=iddata(ymo,mergedata,900);
oiddtv=iddata(zeros(length(oycomp),1),mergedatav,900);
na=odarx(1);nb=[odarx(2) odarx(2) odarx(2)];
nk=[odarx(3) odarx(3) odarx(3)];  %% check nk=delayest(Data,na,nb,nkmin,nkmax,maxtest)
opt=arxOptions('InitialCondition','auto','focus','prediction');
sys=arx(oiddt1,[na nb nk],opt);
oyp=predict(model,iddtr,6);
oyp=oyp.outputdata+(mean(go(cph:end)));
yfor=forecast(model,oiddt,4);
yfor=yfor.outputdata+res;
fc=sqrt(goodnessOfFit(oyp(1:30),oycomp(1:30)','MSE'));
rm=goodnessOfFit(yfor,oycomp(1:4)','MSE');
xfit1.([ 'iter' num2str(i)]).(['modeldays' sprintf('%d',dm)])=fc;
rm1.([ 'iter' num2str(i)]).(['modeldays' sprintf('%d',dm)])=rm;
k=cph-96;
dmk(j)=dm;
j=j+1;
end
dmall{i}=dmk;
k=1;
end
for i=1:length(dm1)
     xfit11{i}=struct2cell(xfit1.([ 'iter' num2str(i)]));
     xfit11{i}=cell2mat(xfit11{i}(1:end));
end
figure()
% plot([2 2 2],[mean(cell2mat(struct2cell(fit1.iter1))) std(cell2mat(struct2cell(fit1.iter1))) -std(cell2mat(struct2cell(fit1.iter1)))  ],'*-');
plot(2:max(dm1) ,cellfun(@(x) (mean(x)),xfit11),'*-');
set(gca, 'xtick',2:max(dm1));
xlabel('Days for training ')
ylabel('MSE')
title('Effect of training data on prediction-AR model(next 1 h)')





%% boxplot
col=@(x)reshape(x,numel(x),1);
boxplot2=@(C,varargin)boxplot(cell2mat(cellfun(col,col(C),'uni',0)),cell2mat(arrayfun(@(I)I*ones(numel(C{I}),1),col(1:numel(C)),'uni',0)),varargin{:});
figure()
boxplot2(aic11,'Widths',.5)
set(gca, 'xticklabel',2:max(dm1));
xlabel('Days for training ')
ylabel('AIC')
title('Effect of training data on prediction-AR model')
figure()
hh=boxplot2(fit11);
set(gca, 'xticklabel',2:max(dm1));
set(hh,{'linew'},{2})
xlabel('Days for training ')
ylabel('RMSE(mg/dL)')

figure()
hh=boxplot2(xfit11);
set(gca, 'xticklabel',2:max(dm1));
set(hh,{'linew'},{2})
xlabel('Days for training ')
ylabel('RMSE(mg/dL)-arx')
