function [revoed] = voedresamp(tintgo,voedtime,voeddata)
%Function to resample the carb, fat , steps data

timecarbdta=voedtime;carbdta=voeddata;
timec1=tintgo(1):1:max(tintgo);
recarb=zeros(1,length(timec1));
indco=find(ismember(timec1,timecarbdta));
recarb(indco)=carbdta(:);
recarbdta=reshape(recarb(2:end),15,(length(recarb)-1)/15);
carbr1=sum(recarbdta,1);
firecarbdta=[recarb(1) carbr1]; 
revoed= firecarbdta;
end

