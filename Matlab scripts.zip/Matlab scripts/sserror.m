function [] = sserror(iddtss)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
for nx=2:10
    opts = ssestOptions('InitialState','auto');
    model= ssest(iddtss,nx,'Ts',900,opts);
    fitall.(['fitorder' num2str(nx)])=model.Report.Fit.FitPercent;
mseall.(['mseorder' num2str(nx)])=model.Report.Fit.MSE;
aicall.(['aicorder' num2str(nx)])=model.Report.Fit.AIC;
end

figure()
plot((2:10),cell2mat(struct2cell(fitall)),'*-');
xlabel('Order')
ylabel('Fit%')
figure()
plot((2:10),sqrt(cell2mat(struct2cell(mseall))),'*-');
xlabel('Order')
ylabel('MSE')
figure()
plot((2:10),cell2mat(struct2cell(aicall)),'*-');
title('AIC vs Order','fontsize',12,'fontweight',' bold')
xlabel('Order')
ylabel('AIC')

end

