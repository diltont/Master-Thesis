function [timedata,nextdayarray] = datedata(timestring,voedstring)
%Function to covert datetime to minutes
timeFreestyle=timestring;
glucoseFreestyle=voedstring;
timeStr = datestr(timeFreestyle');
hourNum = hour(timeStr);
minuteNum = minute(timeStr);
minOfDay = hourNum*60 + minuteNum;
minOfDay = minOfDay';
bday=weekday(timeStr);
minDiff = [0 diff(bday')]; % make the length the same by defining first elem 0.

nextdayindex = find(minDiff <0 | minDiff >0 );

nextdayarray = zeros(1,length(glucoseFreestyle));
nextdayarray(nextdayindex) = 1;
nextdayarray = cumsum(nextdayarray)';
timeGlucose = (nextdayarray .* 24 + hourNum) .* 60 + minuteNum;
timedata=timeGlucose;

end

