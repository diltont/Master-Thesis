%% sript for checking the effect of training days on prediction(Scenario 1). The model is built for first two days
% followed by prediction for some time(1 or 2 hour), model trained for
% three days follwed by prediction, model trained by followed by
% prediction.... upto last day of measurement .For every prediction,
% corresponding RMSE value was calculated.

fit1=[];rm1=[];phall=[];dm1=[];
model=[];
k=1;
if timeGlucose(1)>500
    dm1=2:2:max(nextdayarray)-1;
else
    dm1=2:2:max(nextdayarray);
end
for dm=dm1
%dm=2;
ph=(dm*96);
phall(dm-1)=ph;
cph=ph+1;
res=mean(go(k:ph));
ymo=go(k:ph)'-res;
oiddt=iddata(ymo,[],900);
oycomp=go(cph:end);
yri=oycomp-mean(go(cph:end));
iddtr=iddata(yri',[],900);
oodar=arorder1(iddtr);
model=ar(oiddt,oodar-1,'ls','Ts',900);
oyp=predict(model,iddtr,1);
oyp=oyp.outputdata+(mean(go(cph:end)));
yfor=forecast(model,oiddt,4);
yfor=yfor.outputdata+res;
fc=goodnessOfFit(oyp,oycomp','NRMSE');
rm=goodnessOfFit(yfor,oycomp(1:4)','MSE');
fit1.(['modeldays' sprintf('%d',dm)])=fc;
rm1.(['modeldays' sprintf('%d',dm)])=rm;
k=cph;
end
figure()
plot(dm1,cell2mat(struct2cell(fit1)),'*-');
set(gca, 'xtick',dm1);
xlabel('Days for training ')
ylabel('Fit%')
figure()
plot(dm1,cell2mat(struct2cell(rm1)),'*-');
title('Effect of training data on prediction-AR model')
set(gca, 'xtick',dm1);
xlabel('Days for training ')
ylabel('MSE(mmol/L)')
%%
rm1x=[];
k=1;
 for dm=dm1
ph=dm*96;
cph=ph+1;
res=mean(go(k:ph));
ymo=go(k:ph)'-res;
oycomp=go(cph:end);    
rescarb=mean(firecarbdta(k:ph));resvet=mean(firevetdta(k:ph));
resstep=mean(firestep(k:ph));
arcarbmo=(firecarbdta(k:ph)'-rescarb);
arvetmo=(firevetdta(k:ph)'-resvet);
arstepmo=(firestep(k:ph)'-resstep);
mergedata=[arcarbmo arvetmo arstepmo];
mergedatav=[(firecarbdta(cph:end)'-rescarb) (firevetdta(cph:end)'-resvet) (firestep(cph:end)'-resstep)];
oiddt1=iddata(ymo,mergedata,900);
oiddtv=iddata(zeros(length(oycomp),1),mergedatav,900);
na=odarx(1);nb=[odarx(2) odarx(2) odarx(2)];
nk=[odarx(3) odarx(3) odarx(3)];   %% check nk=delayest(Data,na,nb,nkmin,nkmax,maxtest)
opt=arxOptions('InitialCondition','auto','focus','prediction');
sys=arx(oiddt1,[na nb nk],opt);
oypvalarx=forecast(sys,oiddt1,4,oiddtv(1:4));
oypvalarx=oypvalarx.outputdata+res;
%rm=goodnessOfFit(oypvalarx,oycomp(1:4)','MSE');
rm1x.(['modeldays' sprintf('%d',dm)])=goodnessOfFit(oypvalarx,oycomp(1:4)','MSE');
k=cph;
 end
figure()
plot(dm1,cell2mat(struct2cell(rm1x)),'*-');
title('ARx model')
set(gca, 'xtick',dm1);
xlabel('Days for training ')
ylabel('MSE(mmol/L)')
    
    %% case 'ARMAx'
 rm1max=[];
k=1;
 for dm=dm1
ph=dm*96;
cph=ph+1;
res=mean(go(k:ph));
ymo=go(k:ph)'-res;
oycomp=go(cph:end);    
rescarb=mean(firecarbdta(1:end-ph));resvet=mean(firevetdta(1:end-ph));
resstep=mean(firestep(k:ph));
arcarbmo=(firecarbdta(k:ph)'-rescarb);
arvetmo=(firevetdta(k:ph)'-resvet);
arstepmo=(firestep(k:ph)'-resstep);
mergedata=[arcarbmo arvetmo arstepmo];
mergedatav=[(firecarbdta(cph:end)'-rescarb) (firevetdta(cph:end)'-resvet) (firestep(cph:end)'-resstep)];
oiddt1=iddata(ymo,mergedata,900);
oiddtv=iddata(zeros(length(oycomp),1),mergedatav,900);
na=odarmax(1);nb=[odarmax(2) odarmax(2)  odarmax(2)];nc=odarmax(3);
nk=[odarmax(4) odarmax(4)  odarmax(4) ];  %% check nk=delayest(Data,na,nb,nkmin,nkmax,maxtest)
opt=armaxOptions('InitialCondition','zero','focus','prediction');
sys2=armax(oiddt1,[na nb nc nk],opt);
oypvalarmax=forecast(sys2,oiddt1,4,oiddtv(1:4));
oypvalarmax=oypvalarmax.outputdata+res;
%rm=goodnessOfFit(oypvalarx,oycomp(1:4)','MSE');
rm1max.(['modeldays' sprintf('%d',dm)])=goodnessOfFit(oypvalarmax,oycomp(1:4)','MSE');
k=cph;
 end
figure()
plot(dm1,cell2mat(struct2cell(rm1max)),'*-');
title('ARMAx model')
set(gca, 'xtick',dm1);
xlabel('Days for training ')
ylabel('MSE(mmol/L)')
%% state space
 rm1ss=[];
k=1;
 for dm=dm1
ph=dm*96;
cph=ph+1;
res=mean(go(k:ph));
ymo=go(k:ph)'-res;
oycomp=go(cph:end);    
rescarb=mean(firecarbdta(1:end-ph));resvet=mean(firevetdta(1:end-ph));
resstep=mean(firestep(k:ph));
arcarbmo=(firecarbdta(k:ph)'-rescarb);
arvetmo=(firevetdta(k:ph)'-resvet);
arstepmo=(firestep(k:ph)'-resstep);
mergedata=[arcarbmo arvetmo arstepmo];
mergedatav=[(firecarbdta(cph:end)'-rescarb) (firevetdta(cph:end)'-resvet) (firestep(cph:end)'-resstep)];
oiddt1=iddata(ymo,mergedata,900);
oiddtv=iddata(zeros(length(oycomp),1),mergedatav,900);
[sys3,xo]=ssest(iddtss,7,'Ts',900);
oypvalss=forecast(sys3,oiddt1,4,oiddtv(1:4));
oypvalss=oypvalss.outputdata+res;
%rm=goodnessOfFit(oypvalarx,oycomp(1:4)','MSE');
rm1ss.(['modeldays' sprintf('%d',dm)])=goodnessOfFit(oypvalss,oycomp(1:4)','MSE');
k=cph;
 end


%%
figure()
plot(dm1,cell2mat(struct2cell(rm1)),'*-','displayname','AR');
hold on
plot(dm1,cell2mat(struct2cell(rm1x)),'*-','displayname','ARx');
title('Effect of training data on prediction')
set(gca, 'xtick',2:max(nextdayarray));
xlabel('Days for training ')
ylabel('MSE(mmol/L)')
legend('show')
plot(dm1,cell2mat(struct2cell(rm1max)),'*-','displayname','ARMAx');
plot(dm1,cell2mat(struct2cell(rm1ss)),'*-','displayname','State space');
hold off
