function [TAC] = conmat(ymo,yval,model,dt)

yp1=yval;
y1=ymo;
if length(yp1) ~= length(y1)
    error('Matrix:Inputs','Vectors y and yp must be the same length.')
end

LL=0;LM=0;LH=0;ML=0;MM=0;MH=0;HL=0;HM=0;HH=0;
for i=1:length(yp1)
    if (y1(i) <4 && yp1(i) <4)
            LL=LL+1;
    else
        if (y1(i) <4 &&  yp1(i)>=4 &&yp1(i)<=10)
            LM=LM+1;
        else 
            if (y1(i) <4 && yp1(i)>10)
            LH=LH+1;
            else 
                if (y1(i)>=4 &&y1(i)<=10 && yp1(i)<4)
                    ML=ML+1;
                else 
                    if (y1(i)>=4 &&y1(i)<=10 && yp1(i)>=4 &&yp1(i)<=10)
                        MM=MM+1;
                    else 
                        if (y1(i)>=4 &&y1(i)<=10 && yp1(i)>10)
                            MH=MH+1;
                        else
                            if (y1(i) >10 && yp1(i) <4)
                             HL=HL+1;
       else
        if (y1(i) >10 && yp1(i)>=4 && yp1(i)<=10)
            HM=HM+1;
        else 
            if (y1(i) >10 && yp1(i)>10)
            HH=HH+1;
            end
        end 
                            end
                        end
                    end
                end
            end
        end
    end
end
    

%%
subplot(2,2,dt)
% figure()
plot([0 3],[3 3],'k-','linewidth',4)
title(['Confusion matrix:' model],'fontsize',12,'fontweight','bold')
xlim([0 3])
ylim([0 3])
xlabel('Observed','fontsize',12,'fontweight','bold')
ylabel('Predicted','fontsize',12,'fontweight','bold')
hold on
plot([1 1],[0 3],'k-','linewidth',4)
plot([2 2],[0 3],'k-','linewidth',4)
plot([3 3],[0 3],'k-','linewidth',4)
plot([0 3],[0 0],'k-','linewidth',4)
plot([0 3],[1 1],'k-','linewidth',4)
plot([0 3],[2 2],'k-','linewidth',4)
plot([0 3],[3 3],'k-','linewidth',4)
plot([0 0],[0 3],'k-','linewidth',4)
names = {'Low'; 'Medium'; 'High';};
set(gca,'xtick',[.5:2.5],'xticklabel',names,'fontsize',10)
names = {'High'; 'Medium'; 'Low';};
set(gca,'ytick',[.5:2.5],'yticklabel',names,'fontsize',10)
text(.5,2.5,num2str(LL),'fontsize',30,'HorizontalAlignment','center');%points
text(.5,2.2,[num2str((LL)*100/(LL+LM+LH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');%percentage

text(.5,1.5,num2str(LM),'fontsize',30,'HorizontalAlignment','center');
text(.5,1.2,[num2str((LM)*100/(LL+LM+LH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');%percentage


text(.5,.5,num2str(LH),'fontsize',30,'HorizontalAlignment','center');
text(.5,.2,[num2str((LH)*100/(LL+LM+LH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');


text(1.5,2.5,num2str(ML),'fontsize',30,'HorizontalAlignment','center');
text(1.5,2.2,[num2str((ML)*100/(ML+MM+MH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');

text(1.5,1.5,num2str(MM),'fontsize',30,'HorizontalAlignment','center');
text(1.5,1.2,[num2str((MM)*100/(ML+MM+MH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');

text(1.5,.5,num2str(MH),'fontsize',30,'HorizontalAlignment','center');
text(1.5,.2,[num2str((MH)*100/(ML+MM+MH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');

text(2.5,2.5,num2str(HL),'fontsize',30,'HorizontalAlignment','center');
text(2.5,2.2,[num2str((HL)*100/(HL+HM+HH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');

text(2.5,1.5,num2str(HM),'fontsize',30,'HorizontalAlignment','center');
text(2.5,1.2,[num2str((HM)*100/(HL+HM+HH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');

text(2.5,.5,num2str(HH),'fontsize',30,'HorizontalAlignment','center');
text(2.5,.2,[num2str((HH)*100/(HL+HM+HH)) '%'],'fontsize',15,'HorizontalAlignment','center','color','r');

TAC=(LL+MM+HH)/(LM+LH+ML+MH+HL+HM+LL+MM+HH);
TAC=TAC*100;


end

