  

function [f,data_mean,data_diff,md,sd] = bland_altman(data1,data2,model,bs)

[m,n] = size(data1);
if(n>m)
    data1 = data1';
end

if(size(data1)~=size(data2))
    error('Data matrices must be the same size')
end

data_mean = mean([data1,data2],2);  % Mean of values 
data_diff = data1 - data2;              % Difference between data 
md = mean(data_diff);               % Mean of difference 
sd = std(data_diff);                % Std dev of difference  

 subplot(2,2,bs);
 f=gcf;
% if model=='AR'
%     subplot(2,2,1)
% else
%     if model=='ARx'
%     subplot(2,2,2)
%     else
%         if  model=='ARMAx'
%      subplot(2,2,3)    
%         else
%             if model=='State space'
%            subplot(2,2,4)  
%             end
%         end
%     end
% end
plot(data_mean,data_diff,'ok','MarkerSize',10,'LineWidth',2)   % Bland Altman plot
hold on,plot(data_mean,md*ones(1,length(data_mean)),'-g','displayname',['mean diff line:' num2str(md)],'linewidth',4)% Mean difference line  
plot(data_mean,2*sd*ones(1,length(data_mean)),'-r','displayname','+1.96SD','linewidth',2)% Mean plus 2*SD line  
plot(data_mean,-2*sd*ones(1,length(data_mean)),'-b','displayname','-1.96SD','linewidth',2)% Mean minus 2*SD line   
legend('show')
grid on
ylim([-4 6])
title(['Bland Altman plot-' model],'FontSize',12)
xlabel('Mean of two measures','FontSize',10,'fontweight','bold')
ylabel('Difference between two measures','FontSize',10,'fontweight','bold')
