function [ subods,order] = arxarmaxorder(iddt1,mo)
% Function to find na, nb, nk by iteration
z =iddt1;
na = 2:9;
nb=2:9;
nk = 1;
fitall={};
mseall={};
aicall=cell({});
models = cell({});
jj={};
jj1={};dd=[];dd1=[];
ct = 1;
switch mo
    case 'ARx'
for i = 1:length(na)
    na_ = na(i);
    for j=1:length(nb)    
    nb_ = [ nb(j) nb(j) nb(j)]; %nb_ = [nb(j) nb(j) nb(j) nb(j)];
        for k = 1:length(nk)
            nk_ = [ nk(k) nk(k) nk(k)]; % nk_ = [nk(k) nk(k) nk(k) nk(k)]; 
            models{ct} = arx(z,[na_ nb_ nk_]);
           jj{ct}=[na_ nb_(1)  nk_(1)];
            jj1{ct}=sprintf('%d',jj{ct});
            fitall.(['fitorder' sprintf('%d',jj{ct})])=models{1,ct}.Report.Fit.FitPercent;
mseall.(['mseorder' sprintf('%d',jj{ct})])=models{1,ct}.Report.Fit.MSE;
aicall.(['aicorder' sprintf('%d',jj{ct})])=models{1,ct}.Report.Fit.AIC;
ct = ct+1;
        end
    end
    end 
dd=cell2mat(struct2cell(aicall));
 %dd=find(dd==min(dd));
dd=find(abs(min(dd)-dd)<6,3);
subods=cell2mat(jj(dd(2:end)));
odarx=cell2mat(jj(dd(1)));
if isempty(odarx)
dd1=cell2mat(struct2cell(fitall));
dd1=diff(dd1);
odarx=find(dd1<0,1);
end
order=odarx;
figure()
plot(cell2mat(struct2cell(fitall)),'*-','displayname','order 200=[na nb nk]');
xlabel('Order')
ylabel('Fit%')
legend('show','location','northwest')
figure()
plot(cell2mat(struct2cell(mseall)),'*-','displayname','order 200=[na nb nk]');
xlabel('Order')
ylabel('MSE')
legend('show','location','northwest')
figure()
plot(str2num(char(jj1)),cell2mat(struct2cell(aicall)),'*-','displayname','order 200=[na nb nk]');
%set(gca, 'xtick',str2num(char(jj1)));
title('AIC vs Order','fontsize',12,'fontweight',' bold')
xlabel('Order','fontsize',14,'fontweight','bold')
ylabel('AIC','fontsize',14,'fontweight','bold')
legend('show','location','northwest')

case 'ARMAx'
    nc=2:9;
  for i = 1:length(na)
    na_ = na(i);
    nb_ = [ na_ na_ na_]; % nb_ = [na_ na_ na_ na_];
%     for j=1:length(nb)    
%     nb_ = [nb(j) nb(j) nb(j)];
    for j1=1:length(nc)    
    nc_ = nc(j1);
        for k = 1:length(nk)
            nk_ = [ nk(k) nk(k) nk(k)]; %nk_ = [nk(k) nk(k) nk(k) nk(k)];
            opt1=armaxOptions('InitialCondition','auto');
            models{ct} = armax(z,[na_ nb_ nc_ nk_],opt1);
            jj{ct}=[na_ nb_(1) nc_  nk_(1)];
            jj1{ct}=sprintf('%d',jj{ct});
            fitall.(['fitorder' sprintf('%d',jj{ct})])=models{1,ct}.Report.Fit.FitPercent;
mseall.(['mseorder' sprintf('%d',jj{ct})])=models{1,ct}.Report.Fit.MSE;
aicall.(['aicorder' sprintf('%d',jj{ct})])=models{1,ct}.Report.Fit.AIC;
ct = ct+1;
        end
    end 
end
dd=cell2mat(struct2cell(aicall));
% dd=find(dd==min(dd));
dd=find(abs(min(dd)-dd)<5,3);
subods=cell2mat(jj(dd(2:end)));
odarx=cell2mat(jj(dd(1)));
order=odarx;
figure()
plot(str2num(char(jj1)),cell2mat(struct2cell(fitall)),'*-','displayname','order 200=[na/nb nc nk]');
xlabel('Order')
ylabel('Fit%')
legend('show','location','northwest')
figure()
plot(str2num(char(jj1)),cell2mat(struct2cell(mseall)),'*-','displayname','order 200=[na/nb nc nk]');
xlabel('Order')
ylabel('MSE')
legend('show','location','northwest')
figure()
plot(str2num(char(jj1)),cell2mat(struct2cell(aicall)),'*-','displayname','order 2000=[na nb nc nk]');
%set(gca, 'xtick',str2num(char(jj1)));
title('AIC vs Order','fontsize',12,'fontweight',' bold')
xlabel('Order','fontsize',14,'fontweight','bold')
ylabel('AIC','fontsize',14,'fontweight','bold')
legend('show','location','northwest')
end 
end
        
% nc_ = na(i);
%         for k = 1:length(nk)
%             nk_ = [nk(k) nk(k) nk(k)]; 
%             models{ct} = armax(z,[na_ nb_ nc_ nk_]);
%             jj=[na_ nc_ nk_];
%plot(str2num(char(jj1)),cell2mat(struct2cell(fitall)),'*-','displayname','order 2000=[na/nb nk]');
%% other way to find order arx
% NN = struc(2:4,2:5,2:5,2:5,0:4,0:4,0:4);
% V = arxstruc(iddt1,iddtv,NN);
% order = selstruc(V,0);


