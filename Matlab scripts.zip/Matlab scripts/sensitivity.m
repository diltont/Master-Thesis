function [stable] = sensitivity(iddt1,sys,resarx,ypvalarx,types)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
 or=iddt1;
for i=1:length(types)
    type=types(i);
switch type
    case ('carbs')
iddt1.u(:,1)=0;
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
% rchange=(seyval(:)-ypvalarx(:))./(iddt1.u(:,1)-or.u(:,1));
pchange=(mean(pchange));
stable(:,i)=[  mx; mn; ];%stable(:,i)=[ pchange; mx; mn];

    case ('fat')
  iddt1=or;
 iddt1.u(:,2)=0;
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[ mx; mn; ];

 case ('steps')  
 iddt1=or;
 iddt1.u(:,3)=0;
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
 stable(:,i)=[  mx; mn;];

  case('ci')
       iddt1=or;
 iddt1.u(:,1)=1.5*(iddt1.u(:,1));
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[  mx; mn;];

case('fi')
     iddt1=or;
 iddt1.u(:,2)=1.5*(iddt1.u(:,2));
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[  mx; mn; ];

case('si')
     iddt1=or;
 iddt1.u(:,3)=1.5*(iddt1.u(:,3));
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[  mx; mn; ];

case('cd')
     iddt1=or;
 iddt1.u(:,1)=.5*(iddt1.u(:,1));
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[ mx; mn; ];

case('fd')
     iddt1=or;
 iddt1.u(:,2)=.5*(iddt1.u(:,2));
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[  mx; mn; ];

case('sd')
     iddt1=or;
 iddt1.u(:,3)=.5*(iddt1.u(:,3));
seyval=predict(sys,iddt1,1);
seyval=seyval.outputdata+resarx;
pchange=(seyval(:)-ypvalarx(:))./(ypvalarx(:));
mx=max(pchange);mn=min(pchange);
pchange=(mean(pchange));
stable(:,i)=[  mx; mn; ];

end
end
end



