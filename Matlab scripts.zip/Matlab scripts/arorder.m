function [sods, odar] = arorder(go,ymo,res,cendar)
%Function to find ar order.
% sods= sub optimal orders; odar= the selected order
rmseall={};
yptall={};
fitall={};
mseall={};
aicall={};
for od=(2:12)
%od=2;
iddt=iddata(ymo,[],900);
model=ar(iddt,od,'ls','Ts',900);
ycomp=go(end-cendar:end);
ypt=[ ymo(end-od+1:end)' zeros(1,length(ycomp))]';
Aar=model.a(:)';
Aar=Aar(2:od+1);
s=0;
for m=1:length(ypt)-od
ypt(od+m)=-Aar*wrev(ypt(m:od+s)); %% y(t)=-y(t-1)-y(t-2)+e(t)
s=s+1;
end
ypt=ypt+res;
ypt=ypt(end-cendar:end);
yptall.(['predictionorder' num2str(od)])=ypt;
rmseall.(['error' num2str(od)])=sqrt(sum((ycomp(:).*18-ypt(:).*18).^2)/numel(ycomp));
fitall.(['fitorder' num2str(od)])=model.Report.Fit.FitPercent;
mseall.(['mseorder' num2str(od)])=model.Report.Fit.MSE;
aicall.(['aicorder' num2str(od)])=model.Report.Fit.AIC;
% rmseall.(['error' num2str(od)]) = rmseart;
end
dd=cell2mat(struct2cell(aicall));
% odar=find(abs(min(dd)-dd)<5,1);
% odar=cell2mat(jj(dd));
dd=[0;diff(dd)];
odar=find(abs(dd)<5,4);
sods=odar(3:end);
odar=odar(2);
if isempty(odar)
dd1=cell2mat(struct2cell(fitall));
dd1=find(abs(max(dd1)-dd1)<.3,1);
odar=(dd1+1);
end
figure()
plot((2:12),cell2mat(struct2cell(rmseall)),'*-');
xlabel('Order')
ylabel('RMSE Error')
figure()
plot((2:12),cell2mat(struct2cell(fitall)),'*-');
xlabel('Order')
ylabel('Fit%')
figure()
plot((2:12),sqrt(cell2mat(struct2cell(mseall))),'*-');
xlabel('Order')
ylabel('MSE')
figure()
plot((2:12),cell2mat(struct2cell(aicall)),'*-');
title('AIC vs Order','fontsize',12,'fontweight',' bold')
xlabel('Order')
ylabel('AIC')
figure()
hold on
cellfun(@(x) plot(x,'+-'),struct2cell(yptall))
plot(ycomp,'*-','markersize',10)
xlabel('sample points')
ylabel('prediction')
legendNames = {};
for i=2:12
   legendNames{end+1} = sprintf('order%d',i); 
end
legendNames{end+1}=sprintf('Real values');
legend(legendNames,'location','northwest')
hold off

   
    


% iddt=iddata(ymo,[],900);
% model=ar(iddt,4,'ls','Ts',900);
% ycomp=go(end-cendar:end);
% yp=[  ymo(end-3) ymo(end-2) ymo(end-1) ymo(end) zeros(1,length(ycomp))];
% Aar=model.a(:)';yfar=wrev(ymo(end-1:end));
% for m=5:length(yp)
% yp(m)=-model.a(2).*yp(m-1)-model.a(3)*yp(m-2)-model.a(4).*yp(m-3)-model.a(5).*yp(m-4); %% y(t)=-y(t-1)-y(t-2)+e(t)
% end
% yp=yp+res;
end

