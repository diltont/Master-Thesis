% script to cross validate arx and armax
ypvalarx=predict(sys,iddt1,1);
ypvalarx=ypvalarx.outputdata+resarx;
msevalarx=sum((ymoarx+resarx(:)-ypvalarx(:)).^2)/numel(ymoarx);
figure()
plot((ymoarx+resarx),'*-','displayname','modelled(real data)')
hold on
plot(ypvalarx,'o-','displayname','validated with modelled arx')
hold off
legend('show')
%% ARMAX 
ypvalmax=predict(sys2,iddt1,1);
ypvalmax=ypvalmax.outputdata+resarmx;
msevalmax=sum((ymoarmx+resarmx(:)-ypvalmax(:)).^2)/numel(ymoarmx);                      
figure()
plot((ymoarmx+resarmx),'*-','displayname','modelled(real data)')
hold on
plot(ypvalmax,'o-','displayname','validated with modelled armax')
hold off
legend('show')








