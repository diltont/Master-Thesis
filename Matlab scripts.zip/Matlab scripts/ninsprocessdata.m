% Main sciprt for cross validation with insulin input. 

clear 
close all;
id='608';
set(0, 'DefaultFigureVisible', 'on')
addpath('excel datas insulin')
addpath('excel datas medication')
glucosefile = [ num2str(id) '-glucose.xlsx'];
stepfile = [ num2str(id) '-steps.xlsx'];
%heartfile = [ num2str(id) '-heart.xlsx'];
voedingfile=[ num2str(id) '-voedingmanual.xlsx'];
% read data files
glucosedata = readtable(glucosefile,'ReadVariableNames',false);
stepdata = xlsread(stepfile);
%heartdata = xlsread(heartfile);
%voeding=xlsread(voedingfile);
voeding = readtable(voedingfile,'ReadVariableNames',false);


%%
%data in 1 row data
glucose = table2array(glucosedata(:,4));
glucose2 =  table2array(glucosedata(:,5));
%glucose(find(isnan(glucose))) = glucose2(find(isnan(glucose)));
steps = reshape(stepdata,1,[]);
%heart = reshape(heartdata,1,[]);
sprime=any(steps,1);
%hprime=any(heart,1);
figure()
plot(sprime,'+-','displayname','steps')
% hold on
% plot(hprime,'o-','displayname','heart','linewidth',2)
% legend('show')
% ylim([0 2]);
% hold off
%%
% select Freestyle Libre Glucose Data
glucosetime = table2array(glucosedata(:,2));
measurementtype = table2array(glucosedata(:,3));
indices = find(measurementtype == 0);
timeFreestyle = glucosetime(indices);
glucoseFreestyle = glucose(indices);
voedingtime=table2array(voeding(:,1));
carbdta=table2array(voeding(:,3));
vetdta=table2array(voeding(:,2));
dvoed1=datestr(voedingtime);
figure()
plot(datetime(dvoed1),vetdta,'*-','displayname','fatdata')
hold on
plot(datetime(dvoed1),carbdta,'+-','displayname','carbdata');
hold off
datetick('x','keepticks','keeplimits')
legend('show')

% select manual Glucose;
%%
% transform time representation of glucose data

timeStr = datestr(timeFreestyle');
hourNum = hour(timeStr);
minuteNum = minute(timeStr);
minOfDay = hourNum*60 + minuteNum;
minOfDay = minOfDay';

minDiff = [0 diff(minOfDay)]; % make the length the same by defining first elem 0.

nextdayindex = find(minDiff < 0);

nextdayarray = zeros(1,length(glucoseFreestyle));
nextdayarray(nextdayindex) = 1;
nextdayarray = cumsum(nextdayarray)';
timeGlucose = (nextdayarray .* 24 + hourNum) .* 60 + minuteNum;
timesteps=(0:length(steps)-1);
timeheart=timesteps;tgap=[ diff(timeGlucose')];count=length(find(tgap==15));
count1=length(find(tgap>50));
[timeGlucose1,nextdayarraygl]=datedata(timeFreestyle,glucoseFreestyle);
[timecarbdta,nextdayarraycarb]=datedata(voedingtime,carbdta);



%%
%METHOD 2
tintgo=timeGlucose(1):15:max(timeGlucose);
go = interp1(timeGlucose,glucoseFreestyle,tintgo,'linear');
figure();
plot(tintgo,go,'+-',timeGlucose,glucoseFreestyle,'o-','MarkerSize',4);
legend('interpolated data','observed data(real)');
xlabel('Minutes')
ylabel(' Glucose(mmol/L)')

%%
%%METHOD 3(REDUCTION SAMPLING)
sf1=find(ismember(timesteps,tintgo(1)));sf2=find(ismember(timesteps,max(tintgo)));
resteps=steps(sf1:sf2);
steps_split=reshape(resteps(2:end),15,(length(resteps)-1)/15);
firestep=[resteps(1) sum(steps_split,1)];
figure();plot(firestep,'displayname','stepsresamp'); legend('show')
firecarbdta=voedresamp(tintgo,timecarbdta,carbdta);
firevetdta=voedresamp(tintgo,timecarbdta,vetdta);
figure()
plot(firecarbdta,'displayname','carbresamp');
hold on
plot(firevetdta,'displayname','vetresamp');
hold off
legend('show')
figure()
plot(xcorr(firestep,firecarbdta,'coeff'));
%% Insulin data
t=timeFreestyle(1):minutes(15):timeFreestyle(end);
% t=t(1:length(go));
% [VarName6,~,bld1]=importinsulin([num2str(id) '-voeding.xlsx'],'sheet',1,1000);
% bld1=bld1(find(~isnat(bld1)));
% %bld=datetime(datestr(voedingtime));
% inst=find(day(bld1)==day(t(1)),1);
% inend=find(day(bld1)==day(t(end)),1,'last');
% instime=bld1(inst:inend);% datettime format
% [~,ind1] = min(abs(bsxfun(@minus,datenum(t'),datenum(instime)')));
% closest_time = t(ind1);
[insdata ,instimex]=xlsread([ num2str(id) '-insulin.xlsx']);

instime1=datedata(instimex,insdata);%datetime to double
   ia=find(diff(instime1)==0); 
   if isempty(ia)
       instime1=instime1;
   else
   instime1(ia+1)=instime1(ia+1)+1;
   end
fireins=voedresamp(tintgo,instime1,insdata);
%%  whole data profile
figure()
subplot(5,1,1)
plot(t,go,'displayname','Glucose Data ')
ylabel('mmol/L','fontsize',14,'fontweight','bold')
title([' Whole data profile ID-',num2str(id)],'fontsize',16)
legend('show')
subplot(5,1,2)
plot(t,firecarbdta,'r','displayname','Carb Data')
ylabel('grams','fontsize',14,'fontweight','bold')
legend('show')
subplot(5,1,3)
plot(t,firevetdta,'r','displayname','Vet Data')
ylabel('grams','fontsize',14,'fontweight','bold')
ylim([0 100])
legend('show')
subplot(5,1,4)
plot(t,firestep,'r','displayname','Step Data')
ylabel('units','fontsize',14,'fontweight','bold')
legend('show')
subplot(5,1,5)
plot(t,fireins,'r','displayname','ins data')
ylabel('units','fontsize',14,'fontweight','bold')
legend('show')
wholedata=table(char(t'),go' ,firecarbdta' ,firevetdta' ,firestep');
wholedata.Properties.VariableNames = {'Time' 'Glucose' 'Carbohydrates' 'Fat' 'Steps'};
headers = {'Time' 'Glucose' 'Carbohydrates' 'Fat' 'Steps'};
xlswrite([id '-wholedata.xlsx'],[headers;table2cell(wholedata)]);
rtchge=[0 diff(go)./go(1:end-1)];
rtchge=rtchge.*100;
ck=find(abs(rtchge)>5);
figure()
plot(t,rtchge,'*-','displayname','percentage change of glucose/15 min');
hold on
stem(t,firecarbdta,'r','displayname','carbdta')
hold off
legend('show')
figure()
plot(t,mat2gray(rtchge),'*-','displayname','percentage change of glucose/15 min');
hold on
stem(t,mat2gray(firestep),'r','displayname','stepdta')
plot(t,mat2gray(firecarbdta),'*-','displayname','carbdta')
hold off
ylim([0 1.5])
legend('show')
% figure()
% get(iddt1);
% iddt1.InputName = {'Carbohydrates','Fat','Steps'};
% iddt1.InputUnit = {'grams','grams','units'};
% iddt1.OutputName = 'Glucose level';
% iddt1.OutputUnit = 'mmol/L';
% plot(iddt1);

%% AR matlab model
set(0,'DefaultFigureWindowStyle','docked'); 
parcorr(go);
phar=8;cendar=phar-1;       %% Ph=prediction horizon cend=compare end
daymo=(length(go)-phar)*15/(60*24);
ph=length(go)-(daymo*60*24/15);
res=mean(go(1:end-phar));
ymo=go(1:end-phar)'-res;
iddt=iddata(ymo,[],900);
[sar,odar] = arorder(go,ymo,res,cendar);
modelar=ar(iddt,odar,'ls','Ts',900);
ycomp=go(end-cendar:end);
Aar=modelar.a(:)';
PH1=8;
yp=forecast(modelar,iddt,PH1);
yp=yp.outputdata+res;
figure()
plot(ycomp(1:PH1),'*-','linewidth',2,'MarkerSize',10,'displayname','Real data');
hold on
plot(yp,'o-','displayname','predicted','linewidth',1,'MarkerSize',8);
%plot(8.*ones(1,length(ycomp)),'r','displayname','upperthreshold','linewidth',4);
ylim([0 max(go)+2]);
xlabel('Sample points')
ylabel('Glucose value')
hold off
legend('show')
rmsear=sqrt(sum((ycomp(1:PH1)'*18-yp(1:PH1)*18).^2)/numel(yp));
fit=modelar.Report.Fit.FitPercent;
[yval,fitval,mseval]=validar(modelar,iddt,res,ymo);
figure()
plot((ymo+res),'*-','displayname','modelled(real data)')
hold on
plot(yval,'o-','displayname','validated with modelled')
hold off
legend('show')
% figure()
% p = predict(modelar,iddt,1);
% plot(iddt,'b',p,'r');

%% ARx Model
set(0,'DefaultFigureWindowStyle','docked'); 
mend=8;cend=mend-1;%mend= number for data for modelling cend=data points for comparingarcarbmo
resarx=mean(go(1:end-mend));
ymoarx=go(1:end-mend)'-resarx;
ycomparx=go(end-cend:end);
rescarb=mean(firecarbdta(1:end-mend));
resvet=mean(firevetdta(1:end-mend));
resstep=mean(firestep(1:end-mend));
% rescarb=0;
% resvet=0;
% resstep=0;
arcarbmo=(firecarbdta(1:end-mend)'-rescarb);
arvetmo=(firevetdta(1:end-mend)'-resvet);
arstepmo=(firestep(1:end-mend)'-resstep);
arinsmo=fireins(1:end-mend)';
mergedata=[ arinsmo arcarbmo arvetmo arstepmo];
mergedatav=[ fireins(end-cend:end)'  (firecarbdta(end-cend:end)'-rescarb) (firevetdta(end-cend:end)'-resvet) (firestep(end-cend:end)'-resstep)];
iddt1=iddata(ymoarx,mergedata,900);
iddtv=iddata(zeros(length(ycomparx),1),mergedatav,900);
[odarx] = ninsarxarmaxorder(iddt1,'ARx');
na=odarx(1);nb=[odarx(2) odarx(2) odarx(2) odarx(2)];
nk=[odarx(3) odarx(3) odarx(3) odarx(3)];  %% check nk=delayest(Data,na,nb,nkmin,nkmax,maxtest)
opt=arxOptions('InitialCondition','auto','focus','prediction');
sys=arx(iddt1,[na nb nk],opt);ccv=(firecarbdta(end-cend:end)'-rescarb);
fcv=(firevetdta(end-cend:end)'-resvet);scv=(firestep(end-cend:end)'-resstep);
ycarbx=[arcarbmo(end-1) arcarbmo(end) ccv'];
yvetx=[arvetmo(end-1) arvetmo(end) fcv'];
ystepx=[arstepmo(end-1) arstepmo(end) scv'];
yparx=forecast(sys,iddt1,PH1,iddtv(1:PH1));
yparx=yparx.outputdata+resarx;
figure()
plot(ycomparx(1:PH1),'*-','linewidth',2,'MarkerSize',10,'displayname','measured');
hold on
plot(yparx,'o-','displayname','predicted','linewidth',1,'MarkerSize',8);
%plot(8.*ones(1,length(ycomparx)),'r','displayname','upperthreshold','linewidth',4);
ylim([0 max(go)+2]);
xlabel('sample points')
ylabel('glucose value(mMol/L)')
hold off
legend('show')
rmsearx=sqrt(sum((ycomparx(1:PH1)'.*18-yparx(1:PH1).*18).^2)/numel(yparx));


%% ARMAX MODEL
%clearvar yparmax 
[odarmax] = ninsarxarmaxorder(iddt1,'ARMAx');
na=odarmax(1);nb=[odarmax(2) odarmax(2) odarmax(2)  odarmax(2)];nc=odarmax(3);
nk=[odarmax(4) odarmax(4) odarmax(4)  odarmax(4) ];  %% check nk=delayest(Data,na,nb,nkmin,nkmax,maxtest)
opt1=armaxOptions('InitialCondition','auto');
sys2=armax(iddt1,[na nb nc nk],opt1);
resarmx=mean(go(1:end-mend));
ymoarmx=go(1:end-mend)'-resarmx;
ymoarmx1=[ymoarmx' zeros(1,length(ycomparx))];
et=resid(iddt1,sys2);
yparmax=forecast(sys2,iddt1,PH1,iddtv(1:PH1));
yparmax=yparmax.outputdata+resarmx;
figure()
plot(ycomparx((1:PH1)),'*-','linewidth',2,'MarkerSize',10,'displayname','measured');
hold on
plot(yparmax,'o-','displayname','predicted','linewidth',1,'MarkerSize',8);
%plot(8.*ones(1,length(ycomparx)),'r','displayname','upperthreshold','linewidth',4);
ylim([0 max(go)+2]);
xlabel('sample points')
ylabel('glucose value(mMol/L)')
hold off
legend('show')
rmsearmax=sqrt(sum((ycomparx(1:PH1)'.*18-yparmax(1:PH1).*18).^2)/numel(yparmax));
validarmax;
%% State space model
mendss=8;cendss=mendss-1;%mend= number for data for modelling cend=data points for comparingarcarbmo
resss=mean(go(1:end-mendss));
ymoss=go(1:end-mendss)'-resss;
ycompss= go(end-cendss:end);
rescarbss=mean(firecarbdta(1:end-mendss));resvetss=mean(firevetdta(1:end-mendss));
resstepss=mean(firestep(1:end-mendss));
arcarbss=(firecarbdta(1:end-mendss)'-rescarbss);
arvetss=(firevetdta(1:end-mendss)'-resvetss);
arstepss=(firestep(1:end-mendss)'-resstepss);
arinss=fireins(1:end-mend)';
mergedatass=[arinss arcarbss arvetss arstepss];
iddtss=iddata(ymoss,mergedatass,900);
nx=1:10;
opts = ssestOptions('InitialState','auto');
[sys3,xo]=ssest(iddtss,'best','Ts',900,opts);%best to get best nx without the graph
odss=size(sys3.A,1);
etss=resid(iddtss,sys3);
etss=etss.outputdata;
% etss=[etss' zeros(1,length(ycompss))];
% uk=[firecarbdta'-rescarbss firevetdta'-resvetss firestep'-resstepss];
% for k=1:length(uk)-1
%     xo(:,k+1)=sys3.A*xo(:,k)+sys3.B*uk(k,:)'+sys3.K*etss(k);
% end
ypvalss=predict(sys3,iddtss,1);
ypvalss=ypvalss.outputdata+resss;
ypss=forecast(sys3,iddtss,PH1,iddtv(1:PH1));
ypss=ypss.outputdata ;
ypss=ypss+resss ;
figure()
plot(ymoss+resss,'*-','displayname','modelled(real data)')
hold on
plot(ypvalss,'o-','displayname',[' State Space:' num2str(sys3.Report.Fit.FitPercent) '%'])
hold off
xlabel('Prediction Horizon(minutes)','fontsize',14,'fontweight','bold')
ylabel('glucose value(mmol/L)','fontsize',14,'fontweight','bold')
set(gca,'fontsize',12)
legend('show')
rmsess=sqrt(sum((ycompss(1:PH1)'.*18-ypss(1:PH1).*18).^2)/numel(ypss));
msevalss=sum((ymoss+resss(:)-ypvalss(:)).^2)/numel(ymoss);
figure()
plot(ycompss(1:PH1),'*-','linewidth',2,'MarkerSize',10,'displayname','measured');
hold on
plot(ypss,'o-','displayname','predicted','linewidth',1,'MarkerSize',8);
ylim([0 max(go)+2]);
xlabel('sample points')
ylabel('glucose value(mMol/L)')
hold off
legend('show')

%% All models simulated response
close all
set(0,'DefaultFigureWindowStyle','normal')
h=figure();
plot((ymoarx+resarx),'*-','displayname','observed data(real)')
title(['Fit percenatge of different models for one step prediction:ID-' num2str(id)],'FontSize',12)
hold on
plot(yval,'o-','displayname',['AR:' num2str(modelar.Report.Fit.FitPercent) '%'])
plot(ypvalarx,'o-','displayname',['ARx:' num2str(sys.Report.Fit.FitPercent) '%'])
plot(ypvalmax,'o-','displayname',['ARMAx:' num2str(sys2.Report.Fit.FitPercent) '%'])
plot(ypvalss,'o-','displayname',[' State Space:' num2str(sys3.Report.Fit.FitPercent) '%'])
hold off
xlabel('Sample points','fontsize',14,'fontweight','bold')
ylabel('Glucose value(mmol/l)','fontsize',14,'fontweight','bold')
legend('show','location','northwest')
set(gca,'fontsize',12)
set(gcf,'units','normalized','outerposition',[0 0 1 1])
% set(h, 'units', 'inches')
% set(h, 'Position', [8 8 10 10])
% print(h,'-dpng',['D:\Results\Insulin\' num2str(id) '\cross validation\fitall'])
%% RMSE Error plots
set(0,'DefaultFigureWindowStyle','normal')
h=figure();
plot(15:15:15*(PH1),(ycomp(1:PH1)),'*-','displayname','observed data(real)','markersize',12)
title(['PRMSE(' num2str(15*PH1/60) ' hour) of different models:ID-' num2str(id)],'FontSize',12)
hold on
plot(15:15:15*(PH1),yp,'o-','displayname',['AR: ' num2str(rmsear/18) 'mmol/l'])
plot(15:15:15*(PH1),yparx,'o-','displayname',['ARx: ' num2str(rmsearx/18) 'mmol/l'])
plot(15:15:15*(PH1),yparmax,'o-','displayname',['ARMAx: ' num2str(rmsearmax/18) 'mmol/l'])
plot(15:15:15*(PH1),ypss,'o-','displayname',[' State Space: ' num2str(rmsess/18) 'mmol/l'])
set(gca, 'xtick',15:15:15*(PH1));
xlim([15 15*(PH1)])
ylim([0 15])
hold off
xlabel('Prediction Horizon(minutes)','fontsize',14,'fontweight','bold')
ylabel('glucose value(mmol/L)','fontsize',14,'fontweight','bold')
legend('show')
set(gcf,'units','normalized','outerposition',[0 0 1 1])
% print(h,'-dpng',['D:\Results\Insulin\' num2str(id) '\prmseall'])
%% bland altman plots
close all
set(0,'DefaultFigureWindowStyle','normal'); 
txt='AR';
bland_altman(ymo+res,yval,txt,1);
txt='ARx';
bland_altman(ymoarx+resarx,ypvalarx,txt,2);
txt='ARMAx';
bland_altman(ymoarmx+resarmx,ypvalmax,txt,3);
txt='State space';
bland_altman(ymoss+resss,ypvalss,txt,4);
h=gcf;
set(h,'units','normalized','outerposition',[0 0 1 1])
% print(h,'-dpng',['D:\Results\insulin\' num2str(id) '\cross validation\baltall'])

%% Clarke error grids
close all
set(0,'DefaultFigureWindowStyle','normal'); 
txt='AR';
[t1,p1]=clarke(ymo+res,yval,txt,1);
txt='ARx';
[t2,p2]=clarke(ymoarx+resarx,ypvalarx,txt,2);
txt='ARMAx';
[t3,p3]=clarke(ymoarmx+resarmx,ypvalmax,txt,3);
txt='State space';
[t4,p4]=clarke(ymoss+resss,ypvalss,txt,4);
h=gcf;
set(h,'units','normalized','outerposition',[0 0 1 1])
% print(h,'-dpng',['D:\Results\insulin\' num2str(id) '\cross validation\clarkeall'])
%% Confusion matrices
close all
set(0,'DefaultFigureWindowStyle','normal'); 
txt='AR';
ta1=conmat(ymo+res,yval,txt,1);
txt='ARx';
ta2=conmat(ymoarx+resarx,ypvalarx,txt,2);
txt='ARMAx';
ta3=conmat(ymoarmx+resarmx,ypvalmax,txt,3);
txt='State space';
ta4=conmat(ymoss+resss,ypvalss,txt,4);
h=gcf;
set(h,'units','normalized','outerposition',[0 0 1 1])
% print(h,'-dpng',['D:\Results\insulin\' num2str(id) '\cross validation\conall'])
%% Results table
% tpod=(length(timeFreestyle)/(96*(max(nextdayarray)+1)))*100;
h=histogram(nextdayarraygl,'Visible','on');
pod=(h.BinCounts/96)*100;
c80=0;c90=0;
for i=1:length(pod)
    if pod(i)>90
        c90=c90+1;
    else
        if pod(i)<90 && pod(i)>79
            c80=c80+1;
        end
    end
end
tpod=mean(pod);
spday=mean(sum(stepdata));
restbl=table(str2num(id),odar,{odarx},{odarmax},{odss},rmsear,rmsearx,rmsearmax,rmsess, .......
    modelar.Report.Fit.FitPercent,sys.Report.Fit.FitPercent,.......
    sys2.Report.Fit.FitPercent,sys3.Report.Fit.FitPercent,{p1},{p2},{p3},{p4},c80,c90,tpod,....
    max(nextdayarraygl)+1,round(spday),....
    ta1,ta2,ta3,ta4);

AA=[str2num(id),rmsear,rmsearx,rmsearmax,rmsess, .......
    modelar.Report.Fit.FitPercent,sys.Report.Fit.FitPercent,.......
    sys2.Report.Fit.FitPercent,sys3.Report.Fit.FitPercent,p1(1),p1(2),p2(1),p2(2),p3(1),p3(2),p4(1),p4(2),ta1,ta2,ta3,ta4];
AA1=[str2num(id),p1(1),p1(2),p2(1),p2(2),p3(1),p3(2),p4(1),p4(2)];
filename = 'testdata.xlsx';

xlswrite(filename,AA)
%%
types=["ins" "ic" "id" ];
[ stablex]=senins(iddt1,sys,resarx,ypvalarx,types);
stable(1:2,:)=stablex;%reshape(stablex,1,numel(stablex));
[ stablema]=senins(iddt1,sys2,resarx,ypvalmax,types);
stable(3:4,:)=stablema;%reshape(stablema,1,numel(stablema));
[ stabless]=senins(iddtss,sys3,resss,ypvalss,types);
stable(5:6,:)=stabless;%reshape(stabless,1,numel(stabless));
filename = 'sensdata.xlsx';
xlswrite(filename,stable)







