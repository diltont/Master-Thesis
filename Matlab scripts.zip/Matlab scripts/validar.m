function [yval,fitval,mseval ] = validar(model,iddt,res,ymo)
%cross validation ar


%fit=sum((abs(ymo1(:)-yval(:)))/(abs(ymo1(:)-res)));
yval=predict(model,iddt,1);
yval=yval.outputdata+res;
mseval=goodnessOfFit(yval,ymo+res,'MSE');
fitval=goodnessOfFit(yval,ymo+res,'NRMSE');
end


